<?php  
require 'mail.php';
//confirm_mail();
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		ggyhedgv
	</title>
</head>
<body>

		
	<form action="phpmailtest.php" method="post">
<button name="submit"></button> 
</form>
</body>
<?php 
if(isset($_POST['submit'])==1)
{
	confirm_mail();
}
?>
</html>